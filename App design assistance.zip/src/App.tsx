import { useState, useEffect } from 'react'

type Tab = 'life' | 'love' | 'career' | 'activities' | 'mind'
type Screen = 'splash' | 'slots' | Tab

interface Stats { health: number; happiness: number; smarts: number; looks: number }
type EventTone = 'good' | 'bad' | 'neutral'
interface LogEntry { id: number; year: number; text: string; tone: EventTone }

// ── Palette ── two accent colours + neutrals only ──────────────────────────
const G = '#34C759'   // green  — positive / active
const R = '#EF4444'   // red    — negative
const BORDER: Record<EventTone, string> = { good: G, bad: R, neutral: '#C6C6C8' }
const LABEL:  Record<EventTone, string> = { good: G, bad: R, neutral: '#8E8E93' }

const INITIAL_STATS: Stats = { health: 78, happiness: 62, smarts: 84, looks: 71 }

const INITIAL_LOG: LogEntry[] = [
  { id: 1, year: 22, text: 'Graduated from University of Nairobi with First Class Honours.', tone: 'good'    },
  { id: 2, year: 23, text: 'Started as Junior Business Analyst at Safaricom.',               tone: 'good'    },
  { id: 3, year: 24, text: 'Sick with the flu for two weeks.',                               tone: 'bad'     },
  { id: 4, year: 24, text: 'Visited Diani Beach with friends.',                              tone: 'good'    },
  { id: 5, year: 25, text: 'Received a 15% pay raise after an excellent review.',            tone: 'good'    },
]

const POOL_EVENTS = [
  {
    id: 1, tag: 'Career', accentBg: '#1C1C1E',
    title: 'Job Offer in Lagos',
    body: "Your manager is offering you a Senior Analyst role in Lagos at a much higher salary.",
    choices: [
      { l: 'Accept the offer',      logText: 'Accepted a Senior Analyst role in Lagos.', tone: 'good'    as EventTone },
      { l: 'Negotiate remote work', logText: 'Negotiated a remote arrangement.',          tone: 'good'    as EventTone },
      { l: 'Turn it down',          logText: 'Turned down the Lagos job offer.',          tone: 'neutral' as EventTone },
    ]
  },
  {
    id: 2, tag: 'Karma', accentBg: '#1C1C1E',
    title: 'Found a Wallet',
    body: "You found a wallet outside Java House with Ksh 12,000 cash and someone's passport.",
    choices: [
      { l: 'Return everything',  logText: 'Returned the wallet. The owner was relieved.', tone: 'good' as EventTone },
      { l: 'Keep the cash',      logText: 'Kept the cash but handed in the passport.',    tone: 'neutral' as EventTone },
      { l: 'Pocket everything',  logText: 'Pocketed the wallet and walked away.',         tone: 'bad'  as EventTone },
    ]
  },
  {
    id: 3, tag: 'Romance', accentBg: '#1C1C1E',
    title: 'Message from Zawadi',
    body: "Your ex-partner texted you for the first time in three years suggesting coffee.",
    choices: [
      { l: 'Say yes',         logText: 'Met Zawadi for coffee. It felt like old times.', tone: 'good'    as EventTone },
      { l: 'Keep it casual',  logText: 'Had a brief, polite coffee with Zawadi.',        tone: 'neutral' as EventTone },
      { l: 'Leave on read',   logText: 'Left Zawadi on read.',                           tone: 'bad'     as EventTone },
    ]
  },
]

const LOVE_DATA = [
  { name: 'Grace Mwangi',  rel: 'Mother',     age: 54, bond: 92, skin: '#d08b5b', hairC: '#2c1b18' },
  { name: 'David Mwangi',  rel: 'Father',     age: 58, bond: 67, skin: '#614335', hairC: '#2c1b18' },
  { name: 'Brian Mwangi',  rel: 'Brother',    age: 22, bond: 45, skin: '#ac6651', hairC: '#0e0e0e' },
  { name: 'Zawadi Otieno', rel: 'Ex-partner', age: 26, bond: 28, skin: '#edb98a', hairC: '#0e0e0e' },
]

// ─── DiceBear Lorelei avatar (ink-portrait style) ────────────────────────────
// Stable per seed — same seed always renders the same face.
function Face({
  seed = 'default',
  size = 60,
  skin = 'C68642',
  hair = '0C0A00',
  bg = 'f0faf4',
  expression = 'happy',
}: {
  seed?: string
  size?: number
  skin?: string
  hair?: string
  bg?: string
  expression?: 'happy' | 'neutral' | 'sad' | 'surprised'
}) {
  // DiceBear Lorelei — ink-portrait style, stable per seed
  const mouthMap: Record<string, string> = {
    happy: 'happy01,happy02',
    neutral: 'nervous01,nervous02',
    sad: 'sad01,sad02',
    surprised: 'surprised01,surprised02',
  }
  const mouth = mouthMap[expression] ?? 'happy01,happy02'
  const url = [
    `https://api.dicebear.com/9.x/lorelei/svg`,
    `?seed=${encodeURIComponent(seed)}`,
    `&backgroundColor=${bg.replace('#', '')}`,
    `&skinColor=${skin.replace('#', '')}`,
    `&hairColor=${hair.replace('#', '')}`,
    `&mouth[]=${mouth.split(',')[0]}`,
    `&mouth[]=${mouth.split(',')[1]}`,
    `&radius=50`,
    `&size=${size * 2}`,
  ].join('')

  return (
    <img
      src={url}
      width={size}
      height={size}
      style={{ display: 'block', borderRadius: '50%' }}
      alt={seed}
    />
  )
}

// ─── Inline stat bar (horizontal strip) ──────────────────────────────────────
function StatBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <span style={{ fontSize: 10, fontWeight: 600, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#fff' }}>{value}</span>
      </div>
      <div style={{ height: 3, borderRadius: 99, background: 'rgba(255,255,255,0.12)', overflow: 'hidden' }}>
        <div style={{ width: `${value}%`, height: '100%', borderRadius: 99, background: color, transition: 'width 0.6s cubic-bezier(0.34,1.56,0.64,1)' }} />
      </div>
    </div>
  )
}

// ─── Event row — journal style, no card container ────────────────────────────
const TONE_DOT: Record<EventTone, string> = {
  good: '#4CAF79',
  bad: '#E85D5D',
  neutral: '#9CA3AF',
}
const TONE_TEXT: Record<EventTone, string> = {
  good: '#1a3a28',
  bad: '#3a1a1a',
  neutral: '#2a2a3a',
}

function EventStrip({ entry }: { entry: LogEntry }) {
  const dot = TONE_DOT[entry.tone]
  const textColor = TONE_TEXT[entry.tone]
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 11, padding: '7px 0' }}>
      <div style={{
        width: 7, height: 7, borderRadius: '50%', background: dot,
        flexShrink: 0, marginTop: 6,
        boxShadow: `0 0 0 3px ${dot}22`,
      }} />
      <span style={{ fontSize: 14, color: textColor, lineHeight: 1.55, flex: 1 }}>{entry.text}</span>
    </div>
  )
}

// ─── Age section header — subtle year label ───────────────────────────────────
function AgeHeader({ year }: { year: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '18px 0 6px' }}>
      <span style={{
        fontSize: 11, fontWeight: 700, color: '#9CA3AF',
        letterSpacing: '0.08em', textTransform: 'uppercase', flexShrink: 0,
      }}>Age {year}</span>
      <div style={{ flex: 1, height: 1, background: '#E9E9EF' }} />
    </div>
  )
}

// ─── AGE button ───────────────────────────────────────────────────────────────
function AgeBtn({ onTap }: { onTap: () => void }) {
  const [down, setDown] = useState(false)
  return (
    <button
      onPointerDown={() => setDown(true)}
      onPointerUp={() => { setDown(false); onTap() }}
      onPointerLeave={() => setDown(false)}
      style={{
        width: '100%', border: 'none', borderRadius: 18, padding: '0',
        background: 'none', cursor: 'pointer',
        WebkitTapHighlightColor: 'transparent',
        transform: down ? 'scale(0.96)' : 'scale(1)',
        transition: 'transform 0.12s cubic-bezier(0.34,1.56,0.64,1)',
      }}>
      <div style={{
        background: down ? '#1a7a32' : '#22c55e',
        borderRadius: 18,
        padding: '15px 0',
        boxShadow: down ? 'none' : '0 4px 16px rgba(34,197,94,0.4)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        transition: 'background 0.1s, box-shadow 0.1s',
      }}>
        <span style={{
          fontSize: 16, fontWeight: 800, color: '#fff',
          letterSpacing: '0.06em',
          fontFamily: 'var(--font-display)',
        }}>Live Another Year</span>
        <span style={{ fontSize: 16 }}>→</span>
      </div>
    </button>
  )
}

// ─── Event modal ──────────────────────────────────────────────────────────────
function EventModal({ ev, onClose, onPick }: {
  ev: typeof POOL_EVENTS[0]
  onClose: () => void
  onPick: (c: typeof POOL_EVENTS[0]['choices'][0]) => void
}) {
  const [picked, setPicked] = useState(-1)
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 90, padding: '0 20px' }}>
      <div style={{ background: '#fff', borderRadius: 20, width: '100%', maxWidth: 340, overflow: 'hidden', boxShadow: '0 24px 60px rgba(0,0,0,0.28)' }}>
        {/* header */}
        <div style={{ background: '#1C1C1E', padding: '18px 20px 16px' }}>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6 }}>{ev.tag}</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: '#fff', lineHeight: 1.25 }}>{ev.title}</div>
        </div>
        <div style={{ padding: '16px 20px 20px' }}>
          <p style={{ fontSize: 14, color: '#3C3C43', margin: '0 0 16px', lineHeight: 1.6 }}>{ev.body}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            {ev.choices.map((c, i) => (
              <button key={i} onClick={() => {
                if (picked !== -1) return
                setPicked(i)
                setTimeout(() => { onPick(c); onClose() }, 260)
              }} style={{
                background: picked === i ? '#1C1C1E' : '#F2F2F7',
                border: 'none', borderRadius: 12, padding: '13px 16px',
                cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s',
                transform: picked === i ? 'scale(0.97)' : 'scale(1)',
              }}>
                <span style={{ fontSize: 14, color: picked === i ? '#fff' : '#1C1C1E', fontWeight: 500 }}>{c.l}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Nav icons (inline SVG for crisp rendering) ──────────────────────────────
function NavIcon({ id, active }: { id: Tab; active: boolean }) {
  const c = active ? '#34C759' : '#8E8E93'
  const w = 2
  if (id === 'life') return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="4" stroke={c} strokeWidth={w} fill={active ? '#34C75922' : 'none'} />
      <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke={c} strokeWidth={w} strokeLinecap="round" fill="none" />
    </svg>
  )
  if (id === 'love') return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M12 21C12 21 3 15 3 9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 6-9 12-9 12z" stroke={c} strokeWidth={w} fill={active ? '#FF2D5522' : 'none'} strokeLinejoin="round" />
    </svg>
  )
  if (id === 'career') return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <rect x="2" y="9" width="20" height="13" rx="2.5" stroke={c} strokeWidth={w} fill={active ? '#007AFF22' : 'none'} />
      <path d="M8 9V7a4 4 0 0 1 8 0v2" stroke={c} strokeWidth={w} strokeLinecap="round" />
      <line x1="12" y1="14" x2="12" y2="17" stroke={c} strokeWidth={w} strokeLinecap="round" />
    </svg>
  )
  if (id === 'activities') return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <polygon points="13,2 3,14 12,14 11,22 21,10 12,10" stroke={c} strokeWidth={w} strokeLinejoin="round" fill={active ? '#FF950022' : 'none'} />
    </svg>
  )
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M12 3C7 3 3 7 3 12s4 9 9 9 9-4 9-9-4-9-9-9z" stroke={c} strokeWidth={w} fill={active ? '#AF52DE22' : 'none'} />
      <path d="M9 12s1 2 3 2 3-2 3-2" stroke={c} strokeWidth={w} strokeLinecap="round" fill="none" />
      <circle cx="9.5" cy="9.5" r="1" fill={c} />
      <circle cx="14.5" cy="9.5" r="1" fill={c} />
    </svg>
  )
}

// ─── Bottom nav ───────────────────────────────────────────────────────────────
function Nav({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  const items: { id: Tab; label: string }[] = [
    { id: 'life',       label: 'Life'        },
    { id: 'love',       label: 'Love'        },
    { id: 'career',     label: 'Career'      },
    { id: 'activities', label: 'Activities'  },
    { id: 'mind',       label: 'Mind'        },
  ]
  return (
    <nav style={{
      background: '#fff',
      borderTop: '1px solid #E5E5EA',
      display: 'flex',
      padding: '8px 4px 16px',
      flexShrink: 0,
      boxShadow: '0 -1px 0 #E5E5EA',
    }}>
      {items.map(it => {
        const active = it.id === tab
        return (
          <button key={it.id} onClick={() => setTab(it.id)} style={{
            flex: 1, border: 'none', background: 'none', cursor: 'pointer',
            padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            position: 'relative',
          }}>
            {/* active dot indicator */}
            {active && (
              <div style={{
                position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)',
                width: 32, height: 3, borderRadius: 99, background: '#34C759',
              }} />
            )}
            <div style={{
              width: 44, height: 32, borderRadius: 10,
              background: active ? '#34C75914' : 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'background 0.15s',
            }}>
              <NavIcon id={it.id} active={active} />
            </div>
            <span style={{
              fontSize: 10, fontWeight: active ? 700 : 400,
              color: active ? '#34C759' : '#8E8E93',
              letterSpacing: '0.01em',
              transition: 'color 0.15s',
            }}>{it.label}</span>
          </button>
        )
      })}
    </nav>
  )
}

// ─── Splash ───────────────────────────────────────────────────────────────────
function Splash({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2200)
    return () => clearTimeout(t)
  }, [onDone])
  return (
    <div style={{
      height: '100%', background: '#34C759',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10,
    }}>
      <span style={{ fontSize: 64 }}>🌍</span>
      <div style={{ fontSize: 48, fontWeight: 900, color: '#fff', letterSpacing: '-0.02em', fontFamily: 'var(--font-display)' }}>Maisha</div>
      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Live your story</div>
    </div>
  )
}

// ─── Slot picker ──────────────────────────────────────────────────────────────
function Slots({ onStart }: { onStart: () => void }) {
  return (
    <div style={{ height: '100%', background: '#F2F2F7', padding: '56px 16px 24px', overflowY: 'auto' }}>
      <div style={{ fontSize: 28, fontWeight: 700, color: '#1C1C1E', marginBottom: 4, fontFamily: 'var(--font-display)' }}>Maisha</div>
      <div style={{ fontSize: 14, color: '#8E8E93', marginBottom: 24 }}>Choose a life to play</div>

      <button onClick={onStart} style={{ width: '100%', background: '#fff', border: 'none', borderRadius: 16, padding: '14px 16px', marginBottom: 10, cursor: 'pointer', display: 'flex', gap: 14, alignItems: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.08)', textAlign: 'left' }}>
        <div style={{ width: 56, height: 56, borderRadius: 14, overflow: 'hidden', border: '2px solid #34C759', flexShrink: 0 }}>
          <Face seed="amara-kiptoo" size={56} skin="C68642" hair="0C0A00" bg="D1FAE5" expression="happy" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#1C1C1E', marginBottom: 2 }}>Amara Kiptoo</div>
          <div style={{ fontSize: 12, color: '#8E8E93' }}>Age 25 · 🇰🇪 Nairobi, Kenya</div>
          <div style={{ fontSize: 12, color: '#8E8E93', marginTop: 2 }}>Senior Business Analyst</div>
        </div>
        <div style={{ fontSize: 10, fontWeight: 700, background: '#34C759', color: '#fff', borderRadius: 99, padding: '3px 8px', flexShrink: 0 }}>Gen I</div>
      </button>

      {[0, 1].map(i => (
        <button key={i} onClick={onStart} style={{ width: '100%', background: 'transparent', border: '2px dashed #C6C6C8', borderRadius: 16, padding: '20px 16px', marginBottom: 10, cursor: 'pointer', display: 'flex', gap: 14, alignItems: 'center' }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: '#E5E5EA', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, color: '#C7C7CC', flexShrink: 0 }}>+</div>
          <span style={{ fontSize: 14, color: '#8E8E93' }}>Start a new life</span>
        </button>
      ))}
    </div>
  )
}

// ─── Life tab ─────────────────────────────────────────────────────────────────
function LifeTab({ stats, setStats, log, setLog, age, setAge }: {
  stats: Stats; setStats: (s: Stats) => void
  log: LogEntry[]; setLog: (l: LogEntry[]) => void
  age: number; setAge: (n: number) => void
}) {
  const [modal, setModal] = useState<typeof POOL_EVENTS[0] | null>(null)

  const handleAge = () => {
    const n = age + 1
    setAge(n)
    const pool: Omit<LogEntry, 'id' | 'year'>[] = [
      { text: 'Attended a fintech networking event in Westlands.',   tone: 'neutral' },
      { text: 'Had a heated argument with a colleague at work.',     tone: 'bad'     },
      { text: 'Invested Ksh 50,000 in a money market fund.',        tone: 'good'    },
      { text: 'Completed a leadership course, finishing third.',     tone: 'good'    },
      { text: 'Celebrated your birthday quietly with family.',       tone: 'neutral' },
      { text: 'Went for a morning run along Ngong Road.',            tone: 'good'    },
      { text: 'Read a book on personal finance.',                    tone: 'neutral' },
      { text: 'Caught a cold that kept you home for a week.',        tone: 'bad'     },
      { text: 'Helped a neighbour move apartments.',                 tone: 'good'    },
    ]
    const ev = pool[Math.floor(Math.random() * pool.length)]
    setLog([...log, { ...ev, id: Date.now(), year: n }])
    setStats({
      health:    Math.min(100, Math.max(0, stats.health    + (Math.random() > 0.5 ? 2 : -4))),
      happiness: Math.min(100, Math.max(0, stats.happiness + (Math.random() > 0.4 ? 3 : -2))),
      smarts:    Math.min(100, Math.max(0, stats.smarts    + (Math.random() > 0.6 ? 1 :  0))),
      looks:     Math.min(100, Math.max(0, stats.looks     + (Math.random() > 0.7 ? 1 : -2))),
    })
    if (Math.random() < 0.6) setTimeout(() => setModal(POOL_EVENTS[Math.floor(Math.random() * POOL_EVENTS.length)]), 350)
  }

  // group by year, most recent first
  const years = [...new Set([...log].reverse().map(e => e.year))].sort((a, b) => b - a)
  const byYear: Record<number, LogEntry[]> = {}
  ;[...log].reverse().forEach(e => { if (!byYear[e.year]) byYear[e.year] = []; byYear[e.year].push(e) })

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#F5F4F0' }}>

      {/* ── hero ── */}
      <div style={{
        background: 'linear-gradient(160deg, #0B1628 0%, #152238 60%, #1E2F4A 100%)',
        flexShrink: 0,
        padding: '44px 20px 22px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* subtle background texture rings */}
        <div style={{ position: 'absolute', top: -40, right: -40, width: 200, height: 200, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.04)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', top: -20, right: -20, width: 140, height: 140, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.04)', pointerEvents: 'none' }} />

        {/* top row: avatar + name/info + age */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 22 }}>
          {/* avatar */}
          <div style={{
            width: 72, height: 72, borderRadius: 20, overflow: 'hidden', flexShrink: 0,
            boxShadow: '0 0 0 2px rgba(255,255,255,0.12)',
          }}>
            <Face seed="amara-kiptoo" size={72} skin="C68642" hair="0C0A00" bg="1A3A28" expression="happy" />
          </div>

          {/* name + role */}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 20, fontWeight: 700, color: '#fff',
              fontFamily: 'var(--font-display)', lineHeight: 1.2, marginBottom: 4,
            }}>Amara Kiptoo</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>
              🇰🇪 Nairobi · Sr. Analyst
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ fontSize: 10, fontWeight: 700, background: 'rgba(76,175,121,0.25)', color: '#4CAF79', borderRadius: 99, padding: '3px 9px', letterSpacing: '0.04em' }}>Gen I</span>
              <span style={{ fontSize: 10, fontWeight: 700, background: 'rgba(244,185,66,0.2)', color: '#F4B942', borderRadius: 99, padding: '3px 9px', letterSpacing: '0.04em' }}>🌱 Seedling</span>
            </div>
          </div>

          {/* age */}
          <div style={{ textAlign: 'center', flexShrink: 0 }}>
            <div style={{ fontSize: 44, fontWeight: 900, color: '#fff', lineHeight: 1, fontFamily: 'var(--font-display)' }}>{age}</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.35)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 2 }}>years</div>
          </div>
        </div>

        {/* stat bars — 4 in a row */}
        <div style={{ display: 'flex', gap: 14 }}>
          <StatBar label="Health"    value={stats.health}    color="#4CAF79" />
          <StatBar label="Happy"     value={stats.happiness} color="#F4B942" />
          <StatBar label="Smarts"    value={stats.smarts}    color="#4B8EF0" />
          <StatBar label="Looks"     value={stats.looks}     color="#A78BFA" />
        </div>
      </div>

      {/* ── life feed ── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 20px 8px' }}>
        {years.map(yr => (
          <div key={yr}>
            <AgeHeader year={yr} />
            {byYear[yr].map(e => <EventStrip key={e.id} entry={e} />)}
          </div>
        ))}
        <div style={{ height: 8 }} />
      </div>

      {/* ── age button ── */}
      <div style={{ padding: '10px 16px 16px', background: '#F5F4F0', borderTop: '1px solid #E9E9EF', flexShrink: 0 }}>
        <AgeBtn onTap={handleAge} />
      </div>

      {modal && (
        <EventModal
          ev={modal}
          onClose={() => setModal(null)}
          onPick={c => setLog([...log, { id: Date.now(), year: age, text: c.logText, tone: c.tone }])}
        />
      )}
    </div>
  )
}

// ─── iOS-style grouped action list ───────────────────────────────────────────
function ActionGroup({ label, items, danger = false }: {
  label: string
  items: { label: string; onClick?: () => void }[]
  danger?: boolean
}) {
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: '#8E8E93', letterSpacing: '0.06em', textTransform: 'uppercase', padding: '0 4px', marginBottom: 6 }}>{label}</div>
      <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', border: '1px solid #E5E5EA' }}>
        {items.map((it, i) => (
          <button key={it.label} onClick={it.onClick} style={{
            width: '100%', border: 'none', background: 'none', cursor: 'pointer',
            padding: '13px 16px', textAlign: 'left',
            borderBottom: i < items.length - 1 ? '1px solid #F2F2F7' : 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <span style={{ fontSize: 14, color: danger ? R : '#1C1C1E', fontWeight: 400 }}>{it.label}</span>
            <svg width="7" height="12" viewBox="0 0 7 12" fill="none">
              <path d="M1 1l5 5-5 5" stroke="#C6C6C8" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        ))}
      </div>
    </div>
  )
}

// ─── Love tab ─────────────────────────────────────────────────────────────────
const LOVE_ACTIONS = [
  { icon: '☀️', label: 'Spend time together' },
  { icon: '🎁', label: 'Give a gift' },
  { icon: '💬', label: 'Have a deep talk' },
  { icon: '🤝', label: 'Compliment them' },
  { icon: '⚡', label: 'Start an argument' },
]

// Warm avatar backgrounds that contrast well with each skin tone
const PERSON_BG: Record<string, string> = {
  'Grace Mwangi':  'FDE8D0',
  'David Mwangi':  'D4E8F5',
  'Brian Mwangi':  'D5F0E2',
  'Zawadi Otieno': 'F5E0F0',
}

const BOND_LABEL: (b: number) => string = (b) =>
  b >= 85 ? 'Inseparable' : b >= 70 ? 'Close' : b >= 50 ? 'Good' : b >= 30 ? 'Distant' : 'Strained'

function LoveTab() {
  const [open, setOpen] = useState<string | null>(null)

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#F5F4F0' }}>
      {/* header */}
      <div style={{
        background: 'linear-gradient(160deg, #0B1628 0%, #152238 60%, #1E2F4A 100%)',
        padding: '44px 20px 24px', flexShrink: 0,
      }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>Relationships</div>
        <div style={{ fontSize: 28, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)', lineHeight: 1.1 }}>
          Your People
        </div>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.45)', marginTop: 5 }}>
          {LOVE_DATA.length} people in your life
        </div>
      </div>

      {/* list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 20px' }}>
        {LOVE_DATA.map(p => {
          const isOpen = open === p.name
          const bondColor = p.bond >= 70 ? '#4CAF79' : p.bond >= 40 ? '#F4B942' : '#E85D5D'
          const avatarBg = PERSON_BG[p.name] ?? 'E8E0D5'
          const expr: 'happy' | 'neutral' | 'sad' = p.bond > 70 ? 'happy' : p.bond > 40 ? 'neutral' : 'sad'

          return (
            <div key={p.name} style={{ marginBottom: 12 }}>
              <button
                onClick={() => setOpen(isOpen ? null : p.name)}
                style={{
                  width: '100%', border: 'none', background: '#fff',
                  borderRadius: isOpen ? '16px 16px 0 0' : 16,
                  padding: '16px', cursor: 'pointer', textAlign: 'left',
                  display: 'flex', alignItems: 'center', gap: 14,
                  boxShadow: '0 1px 6px rgba(0,0,0,0.07)',
                }}
              >
                {/* avatar with distinct warm bg */}
                <div style={{
                  width: 58, height: 58, borderRadius: 16, overflow: 'hidden', flexShrink: 0,
                  background: `#${avatarBg}`,
                }}>
                  <Face
                    seed={p.name.toLowerCase().replace(/\s+/g, '-')}
                    size={58}
                    skin={p.skin.replace('#', '')}
                    hair={p.hairC.replace('#', '')}
                    bg={avatarBg}
                    expression={expr}
                  />
                </div>

                {/* info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 2 }}>
                    <span style={{ fontSize: 15, fontWeight: 700, color: '#1C1C1E' }}>{p.name}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: bondColor }}>{p.bond}%</span>
                  </div>
                  <div style={{ fontSize: 12, color: '#9CA3AF', marginBottom: 8 }}>{p.rel} · {p.age} yrs</div>
                  {/* bond bar */}
                  <div style={{ height: 4, borderRadius: 99, background: '#F0EFEB', overflow: 'hidden' }}>
                    <div style={{ width: `${p.bond}%`, height: '100%', borderRadius: 99, background: bondColor, transition: 'width 0.5s ease' }} />
                  </div>
                  <div style={{ fontSize: 10, color: '#C0BDB8', marginTop: 4, fontWeight: 600, letterSpacing: '0.04em' }}>
                    {BOND_LABEL(p.bond)}
                  </div>
                </div>

                {/* chevron */}
                <svg width="8" height="14" viewBox="0 0 8 14" fill="none" style={{ flexShrink: 0, opacity: 0.3, transform: isOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}>
                  <path d="M1 1l6 6-6 6" stroke="#1C1C1E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>

              {/* expanded actions */}
              {isOpen && (
                <div style={{
                  background: '#fff', borderRadius: '0 0 16px 16px',
                  borderTop: '1px solid #F0EFEB',
                  padding: '12px 14px 14px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.07)',
                }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                    {LOVE_ACTIONS.map(a => (
                      <button key={a.label} style={{
                        border: '1.5px solid #EEECEA', background: '#FAFAF8',
                        borderRadius: 12, padding: '10px 12px', cursor: 'pointer', textAlign: 'left',
                        display: 'flex', alignItems: 'center', gap: 8,
                      }}>
                        <span style={{ fontSize: 18, flexShrink: 0 }}>{a.icon}</span>
                        <span style={{ fontSize: 12, color: '#3C3C43', fontWeight: 500, lineHeight: 1.3 }}>{a.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ─── Career tab ───────────────────────────────────────────────────────────────
const CAREER_ACTIONS = [
  { icon: '📋', label: 'Apply for a job',    section: 'Job'      },
  { icon: '💰', label: 'Ask for a raise',     section: 'Job'      },
  { icon: '💼', label: 'Work harder',         section: 'Job'      },
  { icon: '🚀', label: 'Look for a side gig', section: 'Job'      },
  { icon: '🏢', label: 'Start a business',    section: 'Ambition' },
  { icon: '🗳️', label: 'Run for office',      section: 'Ambition' },
  { icon: '🏖️', label: 'Retire early',        section: 'Ambition' },
  { icon: '📈', label: 'Invest savings',      section: 'Ambition' },
]

function CareerTab() {
  const [raised, setRaised] = useState(false)
  const [salary, setSalary] = useState(185000)
  const [perf, setPerf]     = useState(72)
  const [years, setYears]   = useState(3)
  const [notification, setNotification] = useState<{ text: string; sub: string } | null>(null)

  const triggerNotif = (text: string, sub: string) => {
    setNotification({ text, sub })
    setTimeout(() => setNotification(null), 2800)
  }

  const handleAction = (label: string) => {
    if (label === 'Ask for a raise') {
      if (!raised) {
        setRaised(true)
        setSalary(s => s + 45000)
        setPerf(p => Math.min(100, p + 8))
        triggerNotif('Raise approved! 🎉', '+Ksh 45,000 per month')
      } else {
        triggerNotif('Too soon to ask again', 'Wait until next year')
      }
    } else if (label === 'Work harder') {
      setPerf(p => Math.min(100, p + 5))
      triggerNotif('Performance up!', 'Your manager noticed the effort')
    } else if (label === 'Apply for a job') {
      triggerNotif('Application sent', 'Response expected in 2–3 weeks')
    } else if (label === 'Start a business') {
      triggerNotif('Business plan drafted', 'Maisha Ventures — early stage')
    } else {
      triggerNotif(label, 'Coming soon in a future update')
    }
  }

  const perfLevel = perf >= 80 ? 'Exceptional' : perf >= 60 ? 'Good' : perf >= 40 ? 'Average' : 'Needs work'
  const perfColor = perf >= 80 ? '#4CAF79' : perf >= 60 ? '#4B8EF0' : perf >= 40 ? '#F4B942' : '#E85D5D'

  const jobActions  = CAREER_ACTIONS.filter(a => a.section === 'Job')
  const bigActions  = CAREER_ACTIONS.filter(a => a.section === 'Ambition')

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#F5F4F0' }}>

      {/* ── dark header ── */}
      <div style={{
        background: 'linear-gradient(160deg, #0B1628 0%, #152238 60%, #1E2F4A 100%)',
        padding: '44px 20px 24px', flexShrink: 0, position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: -30, right: -30, width: 160, height: 160, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.04)', pointerEvents: 'none' }} />

        <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>Career</div>
        <div style={{ fontSize: 28, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)', lineHeight: 1.1, marginBottom: 18 }}>
          Work Life
        </div>

        {/* salary + years row */}
        <div style={{ display: 'flex', gap: 12 }}>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.07)', borderRadius: 14, padding: '14px 16px', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 4 }}>Monthly Salary</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#F4B942', fontFamily: 'var(--font-display)' }}>
              Ksh {salary.toLocaleString()}
            </div>
          </div>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.07)', borderRadius: 14, padding: '14px 16px', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 4 }}>Tenure</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', fontFamily: 'var(--font-display)' }}>
              Year {years}
            </div>
          </div>
        </div>
      </div>

      {/* ── scrollable body ── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 20px' }}>

        {/* notification toast */}
        {notification && (
          <div className="animate-fade-in" style={{
            background: '#0f1e35', borderRadius: 14, padding: '13px 16px',
            marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12,
            boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>{notification.text}</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>{notification.sub}</div>
            </div>
          </div>
        )}

        {/* current role card */}
        <div style={{ background: '#fff', borderRadius: 16, padding: '18px', marginBottom: 14, boxShadow: '0 1px 6px rgba(0,0,0,0.07)' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: '#1C1C1E', marginBottom: 3 }}>Senior Business Analyst</div>
              <div style={{ fontSize: 13, color: '#9CA3AF' }}>Safaricom PLC</div>
            </div>
            <div style={{ background: '#EDF7F0', borderRadius: 10, padding: '6px 12px', textAlign: 'center' }}>
              <div style={{ fontSize: 11, color: '#4CAF79', fontWeight: 700, letterSpacing: '0.04em' }}>🇰🇪 Nairobi</div>
            </div>
          </div>

          {/* seniority pips */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, color: '#C0BDB8', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 7 }}>Seniority</div>
            <div style={{ display: 'flex', gap: 5 }}>
              {['Junior', 'Analyst', 'Senior', 'Lead', 'Director'].map((lbl, i) => (
                <div key={lbl} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <div style={{
                    height: 6, width: '100%', borderRadius: 99,
                    background: i <= 2 ? '#4B8EF0' : '#EEECEA',
                  }} />
                  {i === 2 && <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#4B8EF0' }} />}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
              <span style={{ fontSize: 9, color: '#C0BDB8', letterSpacing: '0.03em' }}>Junior</span>
              <span style={{ fontSize: 9, color: '#4B8EF0', fontWeight: 700 }}>Senior ←</span>
              <span style={{ fontSize: 9, color: '#C0BDB8', letterSpacing: '0.03em' }}>Director</span>
            </div>
          </div>

          {/* performance bar */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
              <span style={{ fontSize: 11, color: '#C0BDB8', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>Performance</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: perfColor }}>{perfLevel} · {perf}%</span>
            </div>
            <div style={{ height: 8, borderRadius: 99, background: '#F0EFEB', overflow: 'hidden' }}>
              <div style={{ width: `${perf}%`, height: '100%', borderRadius: 99, background: perfColor, transition: 'width 0.6s cubic-bezier(0.34,1.56,0.64,1)' }} />
            </div>
          </div>
        </div>

        {/* job actions */}
        <div style={{ marginBottom: 6 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9CA3AF', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10, paddingLeft: 2 }}>Job Actions</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {jobActions.map(a => (
              <button key={a.label} onClick={() => handleAction(a.label)} style={{
                background: '#fff', border: '1.5px solid #EEECEA', borderRadius: 14,
                padding: '14px 14px', cursor: 'pointer', textAlign: 'left',
                boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
                display: 'flex', flexDirection: 'column', gap: 6,
              }}>
                <span style={{ fontSize: 22 }}>{a.icon}</span>
                <span style={{ fontSize: 12.5, fontWeight: 600, color: '#1C1C1E', lineHeight: 1.3 }}>{a.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* ambition actions */}
        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9CA3AF', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10, paddingLeft: 2 }}>Big Ambitions</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {bigActions.map(a => (
              <button key={a.label} onClick={() => handleAction(a.label)} style={{
                background: '#0f1e35', border: 'none', borderRadius: 14,
                padding: '14px 14px', cursor: 'pointer', textAlign: 'left',
                display: 'flex', flexDirection: 'column', gap: 6,
              }}>
                <span style={{ fontSize: 22 }}>{a.icon}</span>
                <span style={{ fontSize: 12.5, fontWeight: 600, color: '#fff', lineHeight: 1.3 }}>{a.label}</span>
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  )
}

// ─── Activities tab ───────────────────────────────────────────────────────────
// ─── Activities tab ───────────────────────────────────────────────────────────
const ACTIVITY_CATS = [
  {
    id: 'outdoors',
    label: 'Outdoors',
    icon: '🌿',
    accent: '#4CAF79',
    accentBg: '#EDF7F0',
    items: [
      { icon: '🏖️', label: 'Go to the beach',   cost: 'Ksh 3,500',  effect: '+Happiness' },
      { icon: '⛺', label: 'Go camping',         cost: 'Ksh 6,000',  effect: '+Health'    },
      { icon: '🎣', label: 'Go fishing',         cost: 'Ksh 1,200',  effect: '+Happiness' },
      { icon: '🧗', label: 'Rock climbing',      cost: 'Ksh 4,500',  effect: '+Health'    },
      { icon: '🚵', label: 'Mountain biking',    cost: 'Ksh 2,800',  effect: '+Health'    },
    ],
  },
  {
    id: 'social',
    label: 'Social',
    icon: '🎉',
    accent: '#4B8EF0',
    accentBg: '#EDF1FD',
    items: [
      { icon: '🥳', label: 'Throw a party',      cost: 'Ksh 18,000', effect: '+Happiness' },
      { icon: '🍽️', label: 'Host a dinner',      cost: 'Ksh 7,000',  effect: '+Happiness' },
      { icon: '✈️', label: 'Travel abroad',       cost: 'Ksh 65,000', effect: '+Smarts'   },
      { icon: '🎭', label: 'Go to a show',        cost: 'Ksh 2,500',  effect: '+Happiness' },
      { icon: '🍻', label: 'Pub night with mates',cost: 'Ksh 3,200',  effect: '+Happiness' },
    ],
  },
  {
    id: 'gambling',
    label: 'Gambling',
    icon: '🎲',
    accent: '#F4B942',
    accentBg: '#FDF6E3',
    items: [
      { icon: '🎰', label: 'Visit the casino',   cost: 'Ksh 10,000', effect: '±Luck'      },
      { icon: '♠️', label: 'Play poker',         cost: 'Ksh 5,000',  effect: '±Luck'      },
      { icon: '🐴', label: 'Bet on horses',      cost: 'Ksh 3,000',  effect: '±Luck'      },
    ],
  },
  {
    id: 'crime',
    label: 'Crime',
    icon: '⚠️',
    accent: '#E85D5D',
    accentBg: '#FDF0F0',
    items: [
      { icon: '🪝', label: 'Pickpocket someone', cost: '',            effect: '−Karma'     },
      { icon: '🔓', label: 'Break & enter',      cost: '',            effect: '−Karma'     },
      { icon: '💊', label: 'Deal drugs',         cost: '',            effect: '−Karma'     },
      { icon: '💸', label: 'Bribe an official',  cost: 'Ksh 50,000', effect: '−Karma'     },
    ],
  },
]

function ActivitiesTab() {
  const [activeTab, setActiveTab] = useState('outdoors')
  const [notification, setNotification] = useState<{ label: string; effect: string } | null>(null)
  const [done, setDone] = useState<Set<string>>(new Set())

  const cat = ACTIVITY_CATS.find(c => c.id === activeTab)!

  const handleDo = (label: string, effect: string) => {
    setDone(prev => new Set(prev).add(label))
    setNotification({ label, effect })
    setTimeout(() => setNotification(null), 2400)
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#F5F4F0' }}>

      {/* ── dark header ── */}
      <div style={{
        background: 'linear-gradient(160deg, #0B1628 0%, #152238 60%, #1E2F4A 100%)',
        padding: '44px 20px 0', flexShrink: 0, position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: -30, right: -30, width: 160, height: 160, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.04)', pointerEvents: 'none' }} />
        <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>Activities</div>
        <div style={{ fontSize: 28, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)', lineHeight: 1.1, marginBottom: 18 }}>
          What will you do?
        </div>

        {/* category tabs */}
        <div style={{ display: 'flex', gap: 4, overflowX: 'auto', paddingBottom: 0 }}>
          {ACTIVITY_CATS.map(c => {
            const active = c.id === activeTab
            return (
              <button key={c.id} onClick={() => setActiveTab(c.id)} style={{
                flexShrink: 0, border: 'none', cursor: 'pointer',
                padding: '9px 14px',
                background: active ? '#fff' : 'transparent',
                borderRadius: '10px 10px 0 0',
                display: 'flex', alignItems: 'center', gap: 6,
                transition: 'background 0.15s',
              }}>
                <span style={{ fontSize: 14 }}>{c.icon}</span>
                <span style={{
                  fontSize: 12, fontWeight: 700,
                  color: active ? '#1C1C1E' : 'rgba(255,255,255,0.5)',
                  transition: 'color 0.15s',
                }}>{c.label}</span>
              </button>
            )
          })}
        </div>
      </div>

      {/* ── activity list ── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 20px', background: '#F5F4F0' }}>

        {/* toast */}
        {notification && (
          <div className="animate-fade-in" style={{
            background: '#0f1e35', borderRadius: 14, padding: '13px 16px',
            marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
          }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{notification.label}</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: cat.accent, background: `${cat.accent}22`, borderRadius: 99, padding: '3px 10px' }}>{notification.effect}</span>
          </div>
        )}

        {/* category accent strip */}
        <div style={{
          background: cat.accentBg, borderRadius: 14, padding: '12px 16px',
          marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10,
          border: `1.5px solid ${cat.accent}33`,
        }}>
          <span style={{ fontSize: 24 }}>{cat.icon}</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#1C1C1E' }}>{cat.label}</div>
            <div style={{ fontSize: 11, color: '#9CA3AF' }}>{cat.items.length} activities available</div>
          </div>
          {cat.id === 'crime' && (
            <div style={{ marginLeft: 'auto', fontSize: 10, fontWeight: 700, color: '#E85D5D', background: '#FDF0F0', borderRadius: 99, padding: '3px 10px', border: '1px solid #E85D5D44' }}>RISKY</div>
          )}
          {cat.id === 'gambling' && (
            <div style={{ marginLeft: 'auto', fontSize: 10, fontWeight: 700, color: '#F4B942', background: '#FDF6E3', borderRadius: 99, padding: '3px 10px', border: '1px solid #F4B94244' }}>CHANCE</div>
          )}
        </div>

        {/* items */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {cat.items.map(item => {
            const spent = done.has(item.label)
            return (
              <button key={item.label} onClick={() => !spent && handleDo(item.label, item.effect)} style={{
                border: 'none', cursor: spent ? 'default' : 'pointer',
                background: spent ? '#EEECEA' : '#fff',
                borderRadius: 14, padding: '14px 16px',
                display: 'flex', alignItems: 'center', gap: 14,
                boxShadow: spent ? 'none' : '0 1px 5px rgba(0,0,0,0.07)',
                transition: 'background 0.15s',
                textAlign: 'left',
              }}>
                <span style={{ fontSize: 28, flexShrink: 0, opacity: spent ? 0.4 : 1 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: spent ? '#9CA3AF' : '#1C1C1E', marginBottom: 3 }}>{item.label}</div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {item.cost && (
                      <span style={{ fontSize: 11, color: '#C0BDB8', fontWeight: 500 }}>{item.cost}</span>
                    )}
                    <span style={{
                      fontSize: 10, fontWeight: 700, color: cat.accent,
                      background: `${cat.accent}18`, borderRadius: 99, padding: '2px 8px',
                      opacity: spent ? 0.5 : 1,
                    }}>{item.effect}</span>
                  </div>
                </div>
                {spent ? (
                  <span style={{ fontSize: 18, flexShrink: 0 }}>✓</span>
                ) : (
                  <div style={{
                    width: 32, height: 32, borderRadius: 10, flexShrink: 0,
                    background: `${cat.accent}18`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <svg width="8" height="12" viewBox="0 0 8 12" fill="none">
                      <path d="M1 1l6 5-6 5" stroke={cat.accent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                )}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ─── Mind & Body tab ─────────────────────────────────────────────────────────
const MIND_SECTIONS = [
  {
    id: 'body',
    label: 'Body',
    icon: '💪',
    accent: '#4CAF79',
    accentBg: '#EDF7F0',
    intro: 'Your body is your foundation.',
    items: [
      { icon: '🏋️', label: 'Go to the gym',      effect: '+Health',    freq: 'Daily',   xp: 12 },
      { icon: '🏊', label: 'Go swimming',         effect: '+Health',    freq: 'Weekly',  xp: 10 },
      { icon: '🥗', label: 'Eat healthy today',   effect: '+Health',    freq: 'Daily',   xp: 6  },
      { icon: '🚰', label: 'Drink more water',    effect: '+Health',    freq: 'Daily',   xp: 4  },
      { icon: '😴', label: 'Get 8 hrs of sleep',  effect: '+Health',    freq: 'Daily',   xp: 8  },
      { icon: '🧘', label: 'Morning stretch',     effect: '+Health',    freq: 'Daily',   xp: 5  },
    ],
  },
  {
    id: 'mind',
    label: 'Mind',
    icon: '🧠',
    accent: '#A78BFA',
    accentBg: '#F3F0FF',
    intro: 'Sharpen your thinking and find calm.',
    items: [
      { icon: '🧘', label: 'Meditate',            effect: '+Happiness', freq: 'Daily',   xp: 10 },
      { icon: '📖', label: 'Read a book',          effect: '+Smarts',   freq: 'Weekly',  xp: 14 },
      { icon: '📓', label: 'Journal your day',     effect: '+Happiness', freq: 'Daily',   xp: 7  },
      { icon: '🧩', label: 'Solve a puzzle',       effect: '+Smarts',   freq: 'Weekly',  xp: 9  },
      { icon: '🎵', label: 'Play an instrument',   effect: '+Happiness', freq: 'Weekly',  xp: 11 },
      { icon: '🌅', label: 'Digital detox day',    effect: '+Happiness', freq: 'Monthly', xp: 16 },
    ],
  },
  {
    id: 'education',
    label: 'Education',
    icon: '📚',
    accent: '#4B8EF0',
    accentBg: '#EDF1FD',
    intro: 'Invest in your future self.',
    items: [
      { icon: '🎓', label: 'Take an online course', effect: '+Smarts',  freq: 'Monthly', xp: 20 },
      { icon: '🗣️', label: 'Learn Swahili poetry',  effect: '+Smarts',  freq: 'Weekly',  xp: 12 },
      { icon: '👨‍⚕️', label: 'See a therapist',      effect: '+Happiness', freq: 'Monthly', xp: 18 },
      { icon: '🏫', label: 'Attend a workshop',     effect: '+Smarts',  freq: 'Monthly', xp: 15 },
      { icon: '✍️', label: 'Write an article',      effect: '+Smarts',  freq: 'Weekly',  xp: 13 },
    ],
  },
]

const FREQ_COLOR: Record<string, string> = {
  Daily: '#4CAF79', Weekly: '#4B8EF0', Monthly: '#A78BFA',
}

function MindTab() {
  const [activeTab, setActiveTab] = useState('body')
  const [done, setDone]           = useState<Set<string>>(new Set())
  const [notification, setNotification] = useState<{ label: string; xp: number; effect: string } | null>(null)

  const sec = MIND_SECTIONS.find(s => s.id === activeTab)!
  const totalXp   = [...done].reduce((sum, key) => {
    const item = MIND_SECTIONS.flatMap(s => s.items).find(i => i.label === key)
    return sum + (item?.xp ?? 0)
  }, 0)
  const doneInSec = sec.items.filter(i => done.has(i.label)).length
  const pctDone   = Math.round((doneInSec / sec.items.length) * 100)

  const handleDo = (label: string, effect: string, xp: number) => {
    if (done.has(label)) return
    setDone(prev => new Set(prev).add(label))
    setNotification({ label, xp, effect })
    setTimeout(() => setNotification(null), 2400)
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#F5F4F0' }}>

      {/* ── dark header ── */}
      <div style={{
        background: 'linear-gradient(160deg, #0B1628 0%, #152238 60%, #1E2F4A 100%)',
        padding: '44px 20px 0', flexShrink: 0, position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: -30, right: -30, width: 160, height: 160, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.04)', pointerEvents: 'none' }} />

        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>Mind & Body</div>
            <div style={{ fontSize: 28, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)', lineHeight: 1.1 }}>
              Take care of yourself
            </div>
          </div>
          {/* XP counter */}
          <div style={{ textAlign: 'right', flexShrink: 0 }}>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#F4B942', fontFamily: 'var(--font-display)', lineHeight: 1 }}>{totalXp}</div>
            <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.3)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>XP today</div>
          </div>
        </div>

        {/* section tabs */}
        <div style={{ display: 'flex', gap: 4 }}>
          {MIND_SECTIONS.map(s => {
            const active = s.id === activeTab
            return (
              <button key={s.id} onClick={() => setActiveTab(s.id)} style={{
                flexShrink: 0, border: 'none', cursor: 'pointer',
                padding: '9px 16px',
                background: active ? '#F5F4F0' : 'transparent',
                borderRadius: '10px 10px 0 0',
                display: 'flex', alignItems: 'center', gap: 6,
                transition: 'background 0.15s',
              }}>
                <span style={{ fontSize: 14 }}>{s.icon}</span>
                <span style={{ fontSize: 12, fontWeight: 700, color: active ? '#1C1C1E' : 'rgba(255,255,255,0.45)', transition: 'color 0.15s' }}>{s.label}</span>
              </button>
            )
          })}
        </div>
      </div>

      {/* ── scrollable body ── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 20px' }}>

        {/* toast */}
        {notification && (
          <div className="animate-fade-in" style={{
            background: '#0f1e35', borderRadius: 14, padding: '12px 16px',
            marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
          }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{notification.label}</span>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: sec.accent, background: `${sec.accent}22`, borderRadius: 99, padding: '3px 9px' }}>{notification.effect}</span>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#F4B942', background: '#F4B94222', borderRadius: 99, padding: '3px 9px' }}>+{notification.xp} XP</span>
            </div>
          </div>
        )}

        {/* section summary bar */}
        <div style={{
          background: '#fff', borderRadius: 16, padding: '16px',
          marginBottom: 14, boxShadow: '0 1px 6px rgba(0,0,0,0.07)',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#1C1C1E', marginBottom: 2 }}>{sec.label} Habits</div>
              <div style={{ fontSize: 12, color: '#9CA3AF' }}>{sec.intro}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: sec.accent, fontFamily: 'var(--font-display)' }}>{doneInSec}/{sec.items.length}</div>
              <div style={{ fontSize: 9, color: '#C0BDB8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>done</div>
            </div>
          </div>
          <div style={{ height: 6, borderRadius: 99, background: '#F0EFEB', overflow: 'hidden' }}>
            <div style={{ width: `${pctDone}%`, height: '100%', borderRadius: 99, background: sec.accent, transition: 'width 0.5s cubic-bezier(0.34,1.56,0.64,1)' }} />
          </div>
        </div>

        {/* items */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {sec.items.map(item => {
            const isDone = done.has(item.label)
            return (
              <button key={item.label} onClick={() => handleDo(item.label, item.effect, item.xp)} style={{
                border: 'none', cursor: isDone ? 'default' : 'pointer',
                background: isDone ? '#EEECEA' : '#fff',
                borderRadius: 14, padding: '14px 16px',
                display: 'flex', alignItems: 'center', gap: 14,
                boxShadow: isDone ? 'none' : '0 1px 5px rgba(0,0,0,0.07)',
                textAlign: 'left', transition: 'background 0.15s',
              }}>
                <span style={{ fontSize: 28, flexShrink: 0, opacity: isDone ? 0.35 : 1 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: isDone ? '#9CA3AF' : '#1C1C1E', marginBottom: 5 }}>{item.label}</div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 10, fontWeight: 700, color: sec.accent, background: `${sec.accent}18`, borderRadius: 99, padding: '2px 8px', opacity: isDone ? 0.5 : 1 }}>{item.effect}</span>
                    <span style={{ fontSize: 10, fontWeight: 700, color: FREQ_COLOR[item.freq], background: `${FREQ_COLOR[item.freq]}18`, borderRadius: 99, padding: '2px 8px', opacity: isDone ? 0.5 : 1 }}>{item.freq}</span>
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#F4B942', background: '#F4B94218', borderRadius: 99, padding: '2px 8px', opacity: isDone ? 0.5 : 1 }}>+{item.xp} XP</span>
                  </div>
                </div>
                {isDone ? (
                  <div style={{ width: 32, height: 32, borderRadius: 10, flexShrink: 0, background: `${sec.accent}22`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 16, color: sec.accent }}>✓</span>
                  </div>
                ) : (
                  <div style={{ width: 32, height: 32, borderRadius: 10, flexShrink: 0, background: `${sec.accent}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <svg width="8" height="12" viewBox="0 0 8 12" fill="none">
                      <path d="M1 1l6 5-6 5" stroke={sec.accent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                )}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ─── App root ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>('splash')
  const [tab, setTab]       = useState<Tab>('life')
  const [stats, setStats]   = useState<Stats>(INITIAL_STATS)
  const [log, setLog]       = useState<LogEntry[]>(INITIAL_LOG)
  const [age, setAge]       = useState(25)

  const inGame    = !['splash', 'slots'].includes(screen)
  const switchTab = (t: Tab) => { setTab(t); setScreen(t) }

  const content = () => {
    if (screen === 'splash') return <Splash onDone={() => setScreen('slots')} />
    if (screen === 'slots')  return <Slots  onStart={() => { setScreen('life'); setTab('life') }} />
    if (tab === 'life')       return <LifeTab stats={stats} setStats={setStats} log={log} setLog={setLog} age={age} setAge={setAge} />
    if (tab === 'love')       return <LoveTab />
    if (tab === 'career')     return <CareerTab />
    if (tab === 'activities') return <ActivitiesTab />
    return <MindTab />
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', minHeight: '100vh', background: '#1C1C1E' }}>
      <div style={{
        width: 360, display: 'flex', flexDirection: 'column',
        background: '#F2F2F7', minHeight: '100vh',
        boxShadow: '0 0 60px rgba(0,0,0,0.4)',
      }}>
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {content()}
        </div>
        {inGame && <Nav tab={tab} setTab={switchTab} />}
      </div>
    </div>
  )
}
